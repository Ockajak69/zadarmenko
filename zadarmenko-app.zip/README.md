# Zadarmenko

Profesionálna filmová platforma s podporou trailerov, prehrávača a admin panelu.